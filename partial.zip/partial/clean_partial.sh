#!/bin/bash

rm calculator_partial
rm lex.yy.o y.tab.o
rm lex.yy.c y.tab.c
rm y.tab.h
